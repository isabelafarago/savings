public class Pessoa {
    String nome;
    int nasc;
    double peso, alt;

    public int calcularIdade(){
        return (2022 - nasc);
    }
    public double calcularImc(){
        return(peso/(alt*alt));
    }
}
