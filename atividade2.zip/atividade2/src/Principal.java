import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class Principal {

    public static void main(String[] args) {
        List<Pessoa> pessoas = new ArrayList<>();
        Entrevista entrevista = new Entrevista();
        Entrevista p500 = new Entrevista();
        Relatorio relatorio= new Relatorio();
        Scanner ler = new Scanner(System.in);

        int dig = 1;
        while (dig == 1) {
            pessoas.add(p500.obterDados());
            System.out.print("Deseja continuar? 1 para sim e 0 para nao.");
            dig = ler.nextInt();
            ler.nextLine();
        }

        double totalEntrevistadas = pessoas.size();
        System.out.println(+ entrevista.cont18+entrevista.cont40);
        System.out.println(relatorio.porcenP(p500.cont18));
        System.out.println(relatorio.porcenP4(p500.cont40));

    }
}

