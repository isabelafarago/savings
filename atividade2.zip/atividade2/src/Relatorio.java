public class Relatorio {

    Entrevista entrevistaT = new Entrevista();
    public double totatT(double cont18, double cont40){
        return (cont18+cont40);
    }
    public double porcenP (double cont18){
        return((entrevistaT.cont18*100/cont18));

    }
    public double porcenP4(double cont40){
        return((entrevistaT.cont40*100/cont40));

    }

}