import java.util.Scanner;

public class Entrevista {
    Scanner ler = new Scanner(System.in);
    int idade;
    double cont18, cont;
    double cont40;
    Pessoa pessoa = new Pessoa();

        public Pessoa obterDados () {
            System.out.print("Nome: ");
            pessoa.nome = ler.next();
            System.out.print("Ano de nascimento: ");
            pessoa.nasc = ler.nextInt();
            idade = pessoa.calcularIdade();
            System.out.println(idade);

            if (idade > 17 && idade < 36) {
                cont18++;
            } else if (idade > 40) {
                cont40++;
            }
            System.out.println(cont18+cont40);
            System.out.println("Peso: ");
            pessoa.peso = ler.nextDouble();
            System.out.print("Altura: ");
            pessoa.alt = ler.nextDouble();

            return pessoa;
        }
    }

